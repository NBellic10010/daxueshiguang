package com.me.service;

import com.me.models.User;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

public interface UserService {
    public User getUserById(int userId);
    public int createUser(int userId,String name,String email);
}