package com.me.serviceimpl;
import javax.annotation.Resource;

import com.me.dao.UserDao;
import com.me.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.me.service.UserService;

import java.util.Date;


@Service("UserServiceImpl")
public class UserServiceImpl implements UserService {

        @Autowired
        private UserDao userDao;

        public User getUserById(int userId) {
            return this.userDao.selectByPrimaryKey(userId);
            //User user = new User();
            //return user;
        }

        public int createUser(int userId,String name,String email){
            User newuser = new User();
            newuser.setName(name);
            newuser.setEmail(email);
            newuser.setId(userId);
            newuser.setCdate(new Date());
            return this.userDao.insertSelective(newuser);
        }


    }