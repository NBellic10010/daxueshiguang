package com.me.Controller;
import javax.annotation.Resource;
import javax.print.DocFlavor;
import javax.servlet.http.HttpServletRequest;

import com.google.gson.Gson;
import com.me.service.UserService;
import com.me.serviceimpl.UserServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.me.models.User;
import com.me.dao.*;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/user")
// /user/**
@SessionAttributes("user")
public class UserController {
    private static Logger log=LoggerFactory.getLogger(UserController.class);
    private UserService userservice;

    // /user/test?id=1
    @RequestMapping(value="/test",method=RequestMethod.GET)
    public ModelAndView test(User user, Model model) {
        ModelAndView mav = new ModelAndView();
        try {
            int userId = user.getId();
            System.out.println("userId:" + userId);
            User userfd = null;
            userfd = this.userservice.getUserById(userId);
            log.debug(userfd.toString());
            mav.addObject("userfd", userfd);
        }
        catch(Exception e){
            StackTraceElement[] info = e.getStackTrace();
            mav.addObject("info",info);
            return mav;
        }
        return mav;

    }

    @RequestMapping(value="/dologin",method = RequestMethod.POST)
    public boolean dologin(HttpServletRequest request,Model model){
        User user = null;
        int Id = Integer.parseInt(request.getParameter("id"));
        user = this.userservice.getUserById(Id);
        if(user == null){
            return false;
        }
        else{
            return true;
        }
    }

    @RequestMapping(value="/doreg",method = RequestMethod.POST)
    public void doregister(HttpServletRequest request,Model model){
        int userId = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        this.userservice.createUser(userId,name,email);
        System.out.println("success");
    }

}